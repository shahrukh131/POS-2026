# F&B HQ — Frontend

Vite + React 18 + React Router 6. Plain CSS, no UI library. No auth: a **"View as"** dropdown in the top bar switches between **HQ Admin** and any **Outlet** (saved in `localStorage`).

## Setup

```bash
cd frontend
npm install
copy .env.example .env      # Windows CMD  (mac/linux: cp .env.example .env)
npm run dev                 # http://localhost:5173
npm run build               # production build -> dist/
```

`.env`:
```
VITE_API_URL=http://localhost:3000
```
The backend must allow CORS from `http://localhost:5173` (e.g. `app.use(cors())`).

## Screens

| View as | Screen | What it does |
|---|---|---|
| HQ | Outlets | List + add outlet (code, name, address) |
| HQ | Menu Items | List, add/edit, activate/deactivate |
| HQ | Assignments | Pick outlet → assign items, price override, availability |
| HQ | Inventory | Pick outlet → stock table, Restock (+qty) and Adjust (+/- with reason) |
| HQ | Reports | Date range → revenue by outlet + top 5 items per outlet |
| Outlet | POS | Menu tiles with price + stock, out-of-stock disabled, cart, checkout → receipt no. (e.g. `DHA-000001`) |

POS checkout sends a `clientId` UUID for idempotency. The same `clientId` is reused if a request fails (network/5xx) so a retry can't create a double sale; a new one is generated after success or a 409. On **409** (insufficient stock) it shows a clear toast and reloads the menu stock.

## API endpoints assumed

**All calls are in `src/api.js`.** Lines marked `// ASSUMED` are guesses — change the path/body there if your Express routes differ. Pages never call `fetch` directly. Responses may be raw or wrapped in `{ data: ... }`; field names are mapped by the `norm*` functions at the bottom of `api.js`.

| Method | Path | Body | Status |
|---|---|---|---|
| GET | `/api/hq/outlets` | | assumed |
| POST | `/api/hq/outlets` | `{ code, name, address }` | assumed |
| GET | `/api/hq/menu-items` | | assumed |
| POST | `/api/hq/menu-items` | `{ name, sku?, category?, basePrice, isActive }` | assumed |
| PATCH | `/api/hq/menu-items/:id` | any of the above (toggle sends `{ isActive }`) | assumed |
| GET | `/api/hq/outlets/:outletId/menu-items` | | assumed |
| POST | `/api/hq/outlets/:outletId/menu-items` | `{ menuItemId, priceOverride \| null, isAvailable }` | assumed |
| PATCH | `/api/hq/outlets/:outletId/menu-items/:menuItemId` | `{ priceOverride \| null, isAvailable }` | assumed |
| GET | `/api/hq/outlets/:outletId/inventory` | | assumed |
| POST | `/api/hq/outlets/:outletId/inventory/:menuItemId/restock` | `{ quantity, note? }` | assumed |
| POST | `/api/hq/outlets/:outletId/inventory/:menuItemId/adjust` | `{ delta, reason }` | assumed |
| GET | `/api/hq/reports/revenue-by-outlet?from=&to=` | → `[{ outletId, code, name, totalRevenue, saleCount }]` | known |
| GET | `/api/hq/reports/top-items?from=&to=&limit=5` | → `[{ outletId, code, items:[{ menuItemId, name, qtySold, revenue }] }]` | known |
| GET | `/api/outlets/:outletId/menu` | → items with `menuItemId, name, price/effectivePrice, stock/quantity, isAvailable` | known |
| POST | `/api/outlets/:outletId/sales` | `{ clientId, items:[{ menuItemId, quantity }] }` → `{ receiptNumber, totalAmount, ... }` | known |

Money is expected as strings (`"1250.00"`) and shown as `৳ 1,250.00`.

## Structure

```
src/
  api.js          # every backend call + response normalizers  <-- edit here
  role.jsx        # "View as" state (localStorage) + outlets list
  ui.jsx          # toast, modal, loading/empty/error states, money()
  App.jsx         # top bar, sidebar, routes
  styles.css
  pages/          # Outlets, MenuItems, Assignments, Inventory, Reports, Pos
```
