/**
 * ============================================================
 *  ALL BACKEND CALLS LIVE IN THIS FILE.
 *  If a path or payload doesn't match your Express routes,
 *  fix it HERE only — pages never call fetch() directly.
 *  Lines marked  // ASSUMED  are guesses; verify them.
 * ============================================================
 */

const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:3000').replace(/\/$/, '');

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

async function request(method, path, body) {
  let res;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(`Cannot reach the API at ${BASE}. Is the backend running?`, 0);
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }

  if (!res.ok) {
    const msg =
      (data && (data.message || data.error?.message || data.error)) ||
      `Request failed (${res.status})`;
    throw new ApiError(typeof msg === 'string' ? msg : JSON.stringify(msg), res.status, data);
  }
  // Accept both raw payloads and { data: ... } envelopes
  return data && typeof data === 'object' && !Array.isArray(data) && 'data' in data ? data.data : data;
}

const get = (p) => request('GET', p);
const post = (p, b) => request('POST', p, b ?? {});
const patch = (p, b) => request('PATCH', p, b ?? {});

const qs = (params) => {
  const s = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null)).toString();
  return s ? `?${s}` : '';
};

/* ---------------- HQ: Outlets ---------------- */
export const listOutlets = () => get('/api/hq/outlets');                    // ASSUMED
export const createOutlet = (body) => post('/api/hq/outlets', body);        // ASSUMED body: { code, name, address }

/* ---------------- HQ: Menu items ---------------- */
export const listMenuItems = () => get('/api/hq/menu-items');               // ASSUMED
export const createMenuItem = (body) => post('/api/hq/menu-items', body);   // ASSUMED body: { name, sku, category, basePrice, isActive }
export const updateMenuItem = (id, body) => patch(`/api/hq/menu-items/${id}`, body); // ASSUMED

/* ---------------- HQ: Outlet assignments ---------------- */
export const listAssignments = (outletId) =>
  get(`/api/hq/outlets/${outletId}/menu-items`);                            // ASSUMED
export const assignMenuItem = (outletId, body) =>
  post(`/api/hq/outlets/${outletId}/menu-items`, body);                     // ASSUMED body: { menuItemId, priceOverride, isAvailable }
export const updateAssignment = (outletId, menuItemId, body) =>
  patch(`/api/hq/outlets/${outletId}/menu-items/${menuItemId}`, body);      // ASSUMED body: { priceOverride, isAvailable }

/* ---------------- HQ: Inventory ---------------- */
export const listInventory = (outletId) => get(`/api/hq/outlets/${outletId}/inventory`); // ASSUMED
export const restockItem = (outletId, menuItemId, quantity, note) =>
  post(`/api/hq/outlets/${outletId}/inventory/${menuItemId}/restock`, { quantity, note }); // ASSUMED
export const adjustItem = (outletId, menuItemId, delta, reason) =>
  post(`/api/hq/outlets/${outletId}/inventory/${menuItemId}/adjust`, { delta, reason });   // ASSUMED

/* ---------------- HQ: Reports ---------------- */
export const revenueByOutlet = (from, to) =>
  get(`/api/hq/reports/revenue-by-outlet${qs({ from, to })}`);              // known
export const topItems = (from, to, limit = 5) =>
  get(`/api/hq/reports/top-items${qs({ from, to, limit })}`);               // known (limit param ASSUMED)

/* ---------------- Outlet POS ---------------- */
export const getOutletMenu = (outletId) => get(`/api/outlets/${outletId}/menu`);         // known
export const createSale = (outletId, body) => post(`/api/outlets/${outletId}/sales`, body); // known; body: { clientId, items: [{ menuItemId, quantity }] }

/* ============================================================
 *  Normalizers: map whatever the backend returns to the shape
 *  the UI uses. Adjust field names here if needed.
 * ============================================================ */
export const normOutlet = (o) => ({
  id: o.id ?? o.outletId,
  code: o.code,
  name: o.name,
  address: o.address ?? o.location ?? '',
  createdAt: o.createdAt,
});

export const normMenuItem = (m) => ({
  id: m.id ?? m.menuItemId,
  name: m.name,
  sku: m.sku ?? '',
  category: m.category ?? '',
  basePrice: m.basePrice ?? m.price ?? '0.00',
  isActive: m.isActive ?? m.active ?? true,
});

// A row of outlet-menu (assignment / POS / inventory). Handles flat or nested `menuItem`.
export const normOutletItem = (r) => {
  const mi = r.menuItem || {};
  const stock =
    r.stock ?? r.quantity ?? r.qty ?? r.inventory?.quantity ?? r.inventory?.stock ?? null;
  return {
    menuItemId: r.menuItemId ?? mi.id ?? r.id,
    name: r.name ?? mi.name ?? '',
    category: r.category ?? mi.category ?? '',
    basePrice: r.basePrice ?? mi.basePrice ?? null,
    priceOverride: r.priceOverride ?? null,
    price: r.effectivePrice ?? r.price ?? r.priceOverride ?? mi.basePrice ?? r.basePrice ?? '0.00',
    isAvailable: r.isAvailable ?? r.available ?? true,
    stock: stock == null ? null : Number(stock),
    updatedAt: r.updatedAt ?? r.inventory?.updatedAt,
  };
};

export const asList = (x) => (Array.isArray(x) ? x : x?.items ?? x?.rows ?? []);
