import { createContext, useContext, useEffect, useState } from 'react';
import { asList, listOutlets, normOutlet } from './api';

// role = { type: 'hq' } | { type: 'outlet', outletId, code, name }
const KEY = 'fnb.viewAs';
const RoleCtx = createContext(null);

const load = () => {
  try { return JSON.parse(localStorage.getItem(KEY)) || { type: 'hq' }; } catch { return { type: 'hq' }; }
};

export function RoleProvider({ children }) {
  const [role, setRoleState] = useState(load);
  const [outlets, setOutlets] = useState([]);
  const [outletsError, setOutletsError] = useState(null);

  const refreshOutlets = async () => {
    try {
      setOutlets(asList(await listOutlets()).map(normOutlet));
      setOutletsError(null);
    } catch (e) {
      setOutletsError(e);
    }
  };
  useEffect(() => { refreshOutlets(); }, []);

  const setRole = (r) => {
    setRoleState(r);
    try { localStorage.setItem(KEY, JSON.stringify(r)); } catch { /* ignore */ }
  };

  return (
    <RoleCtx.Provider value={{ role, setRole, outlets, outletsError, refreshOutlets }}>
      {children}
    </RoleCtx.Provider>
  );
}
export const useRole = () => useContext(RoleCtx);
