import { NavLink, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { useRole } from './role';
import Outlets from './pages/Outlets';
import MenuItems from './pages/MenuItems';
import Assignments from './pages/Assignments';
import Inventory from './pages/Inventory';
import Reports from './pages/Reports';
import Pos from './pages/Pos';

const HQ_NAV = [
  { to: '/hq/outlets', label: 'Outlets' },
  { to: '/hq/menu-items', label: 'Menu Items' },
  { to: '/hq/assignments', label: 'Assignments' },
  { to: '/hq/inventory', label: 'Inventory' },
  { to: '/hq/reports', label: 'Reports' },
];

function ViewAs() {
  const { role, setRole, outlets } = useRole();
  const navigate = useNavigate();
  const value = role.type === 'hq' ? 'hq' : role.outletId;

  const onChange = (e) => {
    const v = e.target.value;
    if (v === 'hq') {
      setRole({ type: 'hq' });
      navigate('/hq/outlets');
    } else {
      const o = outlets.find((x) => String(x.id) === v);
      if (!o) return;
      setRole({ type: 'outlet', outletId: o.id, code: o.code, name: o.name });
      navigate('/pos');
    }
  };

  return (
    <label className="viewas">
      <span>View as</span>
      <select value={value} onChange={onChange}>
        <option value="hq">HQ Admin</option>
        {outlets.map((o) => (
          <option key={o.id} value={o.id}>Outlet: {o.name} ({o.code})</option>
        ))}
        {role.type === 'outlet' && !outlets.some((o) => String(o.id) === String(role.outletId)) && (
          <option value={role.outletId}>Outlet: {role.name} ({role.code})</option>
        )}
      </select>
    </label>
  );
}

export default function App() {
  const { role, outletsError } = useRole();
  const isHq = role.type === 'hq';

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand"><span className="logo">F&amp;B</span> {isHq ? 'HQ Console' : `${role.name} POS`}</div>
        <ViewAs />
      </header>
      {outletsError && (
        <div className="banner">Could not load outlets: {outletsError.message}</div>
      )}
      <div className={isHq ? 'shell' : 'shell shell-full'}>
        {isHq && (
          <nav className="sidebar">
            {HQ_NAV.map((n) => (
              <NavLink key={n.to} to={n.to} className={({ isActive }) => (isActive ? 'nav active' : 'nav')}>
                {n.label}
              </NavLink>
            ))}
          </nav>
        )}
        <main className="content">
          <Routes>
            {isHq ? (
              <>
                <Route path="/hq/outlets" element={<Outlets />} />
                <Route path="/hq/menu-items" element={<MenuItems />} />
                <Route path="/hq/assignments" element={<Assignments />} />
                <Route path="/hq/inventory" element={<Inventory />} />
                <Route path="/hq/reports" element={<Reports />} />
                <Route path="*" element={<Navigate to="/hq/outlets" replace />} />
              </>
            ) : (
              <>
                <Route path="/pos" element={<Pos key={role.outletId} />} />
                <Route path="*" element={<Navigate to="/pos" replace />} />
              </>
            )}
          </Routes>
        </main>
      </div>
    </div>
  );
}
