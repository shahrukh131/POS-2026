import { useState } from 'react';
import { asList, createMenuItem, listMenuItems, normMenuItem, updateMenuItem } from '../api';
import { Badge, DataState, Field, Modal, PageHeader, money, useAsync, useToast } from '../ui';

export default function MenuItems() {
  const toast = useToast();
  const q = useAsync(async () => asList(await listMenuItems()).map(normMenuItem));
  const [editing, setEditing] = useState(null); // null | {} (new) | item
  const [busyId, setBusyId] = useState(null);
  const rows = q.data || [];

  const toggle = async (m) => {
    setBusyId(m.id);
    try {
      await updateMenuItem(m.id, { isActive: !m.isActive });
      toast.success(`${m.name} ${m.isActive ? 'deactivated' : 'activated'}`);
      q.reload();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <PageHeader
        title="Menu Items"
        subtitle="Master menu. Outlets can override price per item."
        actions={<button className="btn btn-primary" onClick={() => setEditing({})}>+ Add item</button>}
      />
      <div className="card">
        <DataState q={q} isEmpty={!rows.length} empty="No menu items yet.">
          <table className="table">
            <thead>
              <tr><th>Name</th><th>SKU</th><th>Category</th><th className="num">Base price</th><th>Status</th><th /></tr>
            </thead>
            <tbody>
              {rows.map((m) => (
                <tr key={m.id} className={m.isActive ? '' : 'dim'}>
                  <td>{m.name}</td>
                  <td className="muted">{m.sku || '—'}</td>
                  <td className="muted">{m.category || '—'}</td>
                  <td className="num">{money(m.basePrice)}</td>
                  <td>{m.isActive ? <Badge tone="green">Active</Badge> : <Badge>Inactive</Badge>}</td>
                  <td className="row-actions">
                    <button className="btn btn-sm" onClick={() => setEditing(m)}>Edit</button>
                    <button className="btn btn-sm" disabled={busyId === m.id} onClick={() => toggle(m)}>
                      {m.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </DataState>
      </div>
      {editing && <ItemForm item={editing} onClose={() => setEditing(null)} onSaved={q.reload} />}
    </>
  );
}

function ItemForm({ item, onClose, onSaved }) {
  const toast = useToast();
  const isNew = !item.id;
  const [form, setForm] = useState({
    name: item.name || '',
    sku: item.sku || '',
    category: item.category || '',
    basePrice: item.basePrice ?? '',
    isActive: item.isActive ?? true,
  });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const body = { ...form, basePrice: Number(form.basePrice).toFixed(2) };
    if (!body.sku) delete body.sku;
    if (!body.category) delete body.category;
    try {
      if (isNew) await createMenuItem(body);
      else await updateMenuItem(item.id, body);
      toast.success(isNew ? 'Menu item created' : 'Menu item updated');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={isNew ? 'Add menu item' : `Edit ${item.name}`} onClose={onClose}>
      <form onSubmit={submit} className="form">
        <Field label="Name"><input value={form.name} onChange={set('name')} required placeholder="Chicken Burger" /></Field>
        <div className="grid-2">
          <Field label="SKU"><input value={form.sku} onChange={set('sku')} placeholder="BRG-001" /></Field>
          <Field label="Category"><input value={form.category} onChange={set('category')} placeholder="Burgers" /></Field>
        </div>
        <Field label="Base price (৳)">
          <input type="number" min="0" step="0.01" value={form.basePrice} onChange={set('basePrice')} required />
        </Field>
        <label className="check"><input type="checkbox" checked={form.isActive} onChange={set('isActive')} /> Active</label>
        <div className="form-actions">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}
