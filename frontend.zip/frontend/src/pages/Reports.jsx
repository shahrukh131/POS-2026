import { useState } from 'react';
import { asList, revenueByOutlet, topItems } from '../api';
import { DataState, PageHeader, money, useAsync } from '../ui';

const iso = (d) => d.toISOString().slice(0, 10);
const today = new Date();
const monthAgo = new Date(Date.now() - 29 * 864e5);

export default function Reports() {
  const [range, setRange] = useState({ from: iso(monthAgo), to: iso(today) });
  const [applied, setApplied] = useState(range);

  const rev = useAsync(async () => asList(await revenueByOutlet(applied.from, applied.to)), [applied]);
  const top = useAsync(async () => asList(await topItems(applied.from, applied.to, 5)), [applied]);

  const revRows = rev.data || [];
  const total = revRows.reduce((s, r) => s + Number(r.totalRevenue || 0), 0);
  const totalSales = revRows.reduce((s, r) => s + Number(r.saleCount || 0), 0);
  const max = Math.max(1, ...revRows.map((r) => Number(r.totalRevenue || 0)));

  return (
    <>
      <PageHeader
        title="Reports"
        subtitle="Revenue and best sellers across outlets."
        actions={
          <form className="range" onSubmit={(e) => { e.preventDefault(); setApplied(range); }}>
            <input type="date" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} />
            <span className="muted">to</span>
            <input type="date" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} />
            <button className="btn btn-primary">Apply</button>
          </form>
        }
      />

      <div className="stats">
        <div className="stat"><span className="muted">Total revenue</span><strong>{money(total)}</strong></div>
        <div className="stat"><span className="muted">Total sales</span><strong>{totalSales}</strong></div>
        <div className="stat"><span className="muted">Outlets</span><strong>{revRows.length}</strong></div>
      </div>

      <div className="card">
        <h2 className="card-title">Revenue by outlet</h2>
        <DataState q={rev} isEmpty={!revRows.length} empty="No sales in this date range.">
          <table className="table">
            <thead><tr><th>Outlet</th><th className="num">Sales</th><th className="num">Revenue</th><th style={{ width: '35%' }} /></tr></thead>
            <tbody>
              {revRows.map((r) => (
                <tr key={r.outletId}>
                  <td><span className="code">{r.code}</span> {r.name}</td>
                  <td className="num">{r.saleCount}</td>
                  <td className="num strong">{money(r.totalRevenue)}</td>
                  <td><div className="bar"><div style={{ width: `${(Number(r.totalRevenue) / max) * 100}%` }} /></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </DataState>
      </div>

      <h2 className="section-title">Top 5 items per outlet</h2>
      <DataState q={top} isEmpty={!(top.data || []).length} empty="No item sales in this date range.">
        <div className="grid-cards">
          {(top.data || []).map((o) => (
            <div className="card" key={o.outletId}>
              <h3 className="card-title"><span className="code">{o.code}</span> {o.name || ''}</h3>
              {!o.items?.length ? (
                <p className="muted">No sales.</p>
              ) : (
                <table className="table compact">
                  <thead><tr><th>#</th><th>Item</th><th className="num">Qty</th><th className="num">Revenue</th></tr></thead>
                  <tbody>
                    {o.items.map((it, i) => (
                      <tr key={it.menuItemId}>
                        <td className="muted">{i + 1}</td>
                        <td>{it.name}</td>
                        <td className="num">{it.qtySold}</td>
                        <td className="num">{money(it.revenue)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          ))}
        </div>
      </DataState>
    </>
  );
}
