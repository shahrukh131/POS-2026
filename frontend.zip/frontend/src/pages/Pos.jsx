import { useMemo, useState } from 'react';
import { asList, createSale, getOutletMenu, normOutletItem } from '../api';
import { DataState, Modal, money, useAsync, useToast } from '../ui';
import { useRole } from '../role';

const uuid = () =>
  crypto.randomUUID
    ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
      });

export default function Pos() {
  const { role } = useRole();
  const toast = useToast();
  const outletId = role.outletId;

  const q = useAsync(async () => asList(await getOutletMenu(outletId)).map(normOutletItem), [outletId]);
  const menu = q.data || [];

  const [search, setSearch] = useState('');
  const [cart, setCart] = useState({}); // menuItemId -> qty
  // One clientId per checkout attempt: kept on retry (idempotent), reset after success.
  const [clientId, setClientId] = useState(uuid);
  const [paying, setPaying] = useState(false);
  const [receipt, setReceipt] = useState(null);

  const byId = useMemo(() => new Map(menu.map((m) => [String(m.menuItemId), m])), [menu]);
  const lines = Object.entries(cart)
    .map(([id, qty]) => ({ item: byId.get(id), qty }))
    .filter((l) => l.item);
  const total = lines.reduce((s, l) => s + Number(l.item.price) * l.qty, 0);

  const filtered = menu.filter((m) => m.name.toLowerCase().includes(search.toLowerCase()));

  const canSell = (m) => m.isAvailable && (m.stock == null || m.stock > 0);

  const add = (m) => {
    const id = String(m.menuItemId);
    const cur = cart[id] || 0;
    if (m.stock != null && cur + 1 > m.stock) { toast.error(`Only ${m.stock} ${m.name} left`); return; }
    setCart({ ...cart, [id]: cur + 1 });
  };
  const setQty = (id, qty) => {
    const next = { ...cart };
    if (qty <= 0) delete next[id];
    else {
      const m = byId.get(id);
      if (m?.stock != null && qty > m.stock) { toast.error(`Only ${m.stock} ${m.name} left`); return; }
      next[id] = qty;
    }
    setCart(next);
  };

  const checkout = async () => {
    if (!lines.length) return;
    setPaying(true);
    try {
      const res = await createSale(outletId, {
        clientId,
        items: lines.map((l) => ({ menuItemId: l.item.menuItemId, quantity: l.qty })),
      });
      const sale = res?.sale ?? res;
      setReceipt({
        number: sale?.receiptNumber ?? sale?.receiptNo ?? sale?.receipt ?? '—',
        total: sale?.totalAmount ?? sale?.total ?? total.toFixed(2),
        lines,
        at: sale?.createdAt ?? new Date().toISOString(),
      });
      setCart({});
      setClientId(uuid());
      q.reload();
    } catch (e) {
      if (e.status === 409) {
        toast.error(`Not enough stock: ${e.message}. Menu refreshed — please update the cart.`);
        setClientId(uuid()); // cart will change, so this is a new sale attempt
        q.reload();
      } else {
        // network/5xx: keep the same clientId so a retry can't double-charge
        toast.error(`Checkout failed: ${e.message}. You can retry safely.`);
      }
    } finally {
      setPaying(false);
    }
  };

  return (
    <div className="pos">
      <section className="pos-menu">
        <div className="pos-toolbar">
          <h1>{role.name} <span className="code">{role.code}</span></h1>
          <input className="search" placeholder="Search menu…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <DataState q={q} isEmpty={!menu.length} empty="No items are assigned to this outlet yet. Ask HQ to assign the menu.">
          {!filtered.length ? (
            <div className="state muted">No items match “{search}”.</div>
          ) : (
            <div className="tiles">
              {filtered.map((m) => {
                const ok = canSell(m);
                const inCart = cart[String(m.menuItemId)] || 0;
                return (
                  <button key={m.menuItemId} className={`tile ${ok ? '' : 'disabled'}`} disabled={!ok} onClick={() => add(m)}>
                    {inCart > 0 && <span className="tile-count">{inCart}</span>}
                    <span className="tile-name">{m.name}</span>
                    <span className="tile-price">{money(m.price)}</span>
                    <span className={`tile-stock ${m.stock != null && m.stock <= 5 ? 'low' : ''}`}>
                      {!m.isAvailable ? 'Unavailable' : m.stock == null ? '' : m.stock <= 0 ? 'Out of stock' : `${m.stock} in stock`}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </DataState>
      </section>

      <aside className="pos-cart card">
        <h2 className="card-title">Current order</h2>
        {!lines.length ? (
          <div className="state muted">Cart is empty. Tap an item to add it.</div>
        ) : (
          <ul className="cart-lines">
            {lines.map(({ item, qty }) => {
              const id = String(item.menuItemId);
              return (
                <li key={id}>
                  <div>
                    <div>{item.name}</div>
                    <small className="muted">{money(item.price)} each</small>
                  </div>
                  <div className="qty">
                    <button className="icon-btn" onClick={() => setQty(id, qty - 1)} aria-label="Decrease">−</button>
                    <span>{qty}</span>
                    <button className="icon-btn" onClick={() => setQty(id, qty + 1)} aria-label="Increase">+</button>
                  </div>
                  <strong className="num">{money(Number(item.price) * qty)}</strong>
                </li>
              );
            })}
          </ul>
        )}
        <div className="cart-total">
          <span>Total</span>
          <strong>{money(total)}</strong>
        </div>
        <button className="btn btn-primary btn-block" disabled={!lines.length || paying} onClick={checkout}>
          {paying ? 'Processing…' : 'Checkout'}
        </button>
        {lines.length > 0 && (
          <button className="btn btn-block btn-ghost" disabled={paying} onClick={() => setCart({})}>Clear</button>
        )}
      </aside>

      {receipt && (
        <Modal title="Sale complete" onClose={() => setReceipt(null)}>
          <div className="receipt">
            <div className="receipt-no">{receipt.number}</div>
            <div className="muted small">{new Date(receipt.at).toLocaleString()}</div>
            <ul>
              {receipt.lines.map(({ item, qty }) => (
                <li key={item.menuItemId}>
                  <span>{qty} × {item.name}</span>
                  <span>{money(Number(item.price) * qty)}</span>
                </li>
              ))}
            </ul>
            <div className="cart-total"><span>Total</span><strong>{money(receipt.total)}</strong></div>
            <button className="btn btn-primary btn-block" onClick={() => setReceipt(null)} autoFocus>New order</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
