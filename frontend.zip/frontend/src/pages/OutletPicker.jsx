import { useEffect } from 'react';
import { useRole } from '../role';

/** Outlet dropdown shared by HQ pages. Auto-selects the first outlet. */
export default function OutletPicker({ value, onChange }) {
  const { outlets } = useRole();
  useEffect(() => {
    if (!value && outlets.length) onChange(outlets[0].id);
  }, [value, outlets, onChange]);

  return (
    <label className="inline-field">
      <span>Outlet</span>
      <select value={value || ''} onChange={(e) => onChange(e.target.value)}>
        {!outlets.length && <option value="">No outlets</option>}
        {outlets.map((o) => (
          <option key={o.id} value={o.id}>{o.name} ({o.code})</option>
        ))}
      </select>
    </label>
  );
}
