import { useCallback, useState } from 'react';
import { adjustItem, asList, listInventory, normOutletItem, restockItem } from '../api';
import { Badge, DataState, Field, Modal, PageHeader, useAsync, useToast } from '../ui';
import OutletPicker from './OutletPicker';

const LOW = 5;

export default function Inventory() {
  const [outletId, setOutletId] = useState('');
  const onPick = useCallback((v) => setOutletId(v), []);
  const [action, setAction] = useState(null); // { type: 'restock'|'adjust', row }

  const q = useAsync(async () => (outletId ? asList(await listInventory(outletId)).map(normOutletItem) : []), [outletId]);
  const rows = q.data || [];

  return (
    <>
      <PageHeader
        title="Inventory"
        subtitle="Stock per outlet. Every change is logged."
        actions={<OutletPicker value={outletId} onChange={onPick} />}
      />
      <div className="card">
        <DataState q={q} isEmpty={!rows.length} empty="No stock rows for this outlet. Assign menu items first.">
          <table className="table">
            <thead><tr><th>Item</th><th className="num">In stock</th><th>Level</th><th>Last updated</th><th /></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.menuItemId}>
                  <td>{r.name}</td>
                  <td className="num strong">{r.stock ?? 0}</td>
                  <td>
                    {(r.stock ?? 0) <= 0 ? <Badge tone="red">Out of stock</Badge>
                      : r.stock <= LOW ? <Badge tone="amber">Low</Badge>
                      : <Badge tone="green">OK</Badge>}
                  </td>
                  <td className="muted">{r.updatedAt ? new Date(r.updatedAt).toLocaleString() : '—'}</td>
                  <td className="row-actions">
                    <button className="btn btn-sm btn-primary" onClick={() => setAction({ type: 'restock', row: r })}>Restock</button>
                    <button className="btn btn-sm" onClick={() => setAction({ type: 'adjust', row: r })}>Adjust</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </DataState>
      </div>
      {action && (
        <StockModal outletId={outletId} {...action} onClose={() => setAction(null)} onSaved={q.reload} />
      )}
    </>
  );
}

function StockModal({ outletId, type, row, onClose, onSaved }) {
  const toast = useToast();
  const isRestock = type === 'restock';
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const n = Number(qty);
  const preview = Number.isFinite(n) && qty !== '' ? (row.stock ?? 0) + n : null;

  const submit = async (e) => {
    e.preventDefault();
    if (!Number.isInteger(n) || n === 0 || (isRestock && n < 0)) {
      toast.error(isRestock ? 'Enter a positive whole number' : 'Enter a non-zero whole number (e.g. -3 or 5)');
      return;
    }
    if (preview < 0) { toast.error('Stock cannot go below 0'); return; }
    setSaving(true);
    try {
      if (isRestock) await restockItem(outletId, row.menuItemId, n, note || undefined);
      else await adjustItem(outletId, row.menuItemId, n, note);
      toast.success(`${row.name}: stock is now ${preview}`);
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={`${isRestock ? 'Restock' : 'Adjust'} — ${row.name}`} onClose={onClose}>
      <form onSubmit={submit} className="form">
        <p className="muted">Current stock: <strong>{row.stock ?? 0}</strong>
          {preview != null && <> → after: <strong>{preview}</strong></>}
        </p>
        <Field label={isRestock ? 'Quantity to add' : 'Change (+/-)'} hint={isRestock ? undefined : 'Use negative for waste/damage, e.g. -2'}>
          <input type="number" step="1" min={isRestock ? 1 : undefined} value={qty} onChange={(e) => setQty(e.target.value)} required autoFocus />
        </Field>
        <Field label={isRestock ? 'Note (optional)' : 'Reason'}>
          <input value={note} onChange={(e) => setNote(e.target.value)} required={!isRestock} placeholder={isRestock ? 'Morning delivery' : 'Damaged / count correction'} />
        </Field>
        <div className="form-actions">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Confirm'}</button>
        </div>
      </form>
    </Modal>
  );
}
