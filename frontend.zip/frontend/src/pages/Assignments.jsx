import { useCallback, useEffect, useState } from 'react';
import {
  asList, assignMenuItem, listAssignments, listMenuItems,
  normMenuItem, normOutletItem, updateAssignment,
} from '../api';
import { Badge, DataState, PageHeader, money, useAsync, useToast } from '../ui';
import OutletPicker from './OutletPicker';

export default function Assignments() {
  const [outletId, setOutletId] = useState('');
  const onPick = useCallback((v) => setOutletId(v), []);

  const q = useAsync(async () => {
    if (!outletId) return [];
    const [items, assigned] = await Promise.all([listMenuItems(), listAssignments(outletId)]);
    const byId = new Map(asList(assigned).map(normOutletItem).map((a) => [String(a.menuItemId), a]));
    return asList(items).map(normMenuItem).map((m) => ({ item: m, assignment: byId.get(String(m.id)) || null }));
  }, [outletId]);

  const rows = q.data || [];

  return (
    <>
      <PageHeader
        title="Assignments"
        subtitle="Choose which menu items each outlet sells, with optional price override."
        actions={<OutletPicker value={outletId} onChange={onPick} />}
      />
      <div className="card">
        <DataState q={q} isEmpty={!rows.length} empty="No menu items. Create some in Menu Items first.">
          <table className="table">
            <thead>
              <tr>
                <th>Item</th><th className="num">Base price</th><th>Status</th>
                <th>Price override (৳)</th><th>Available</th><th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <AssignRow key={r.item.id} outletId={outletId} {...r} onSaved={q.reload} />
              ))}
            </tbody>
          </table>
        </DataState>
      </div>
    </>
  );
}

function AssignRow({ outletId, item, assignment, onSaved }) {
  const toast = useToast();
  const [price, setPrice] = useState('');
  const [available, setAvailable] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setPrice(assignment?.priceOverride ?? '');
    setAvailable(assignment?.isAvailable ?? true);
  }, [assignment]);

  const save = async () => {
    setSaving(true);
    const body = {
      priceOverride: price === '' ? null : Number(price).toFixed(2),
      isAvailable: available,
    };
    try {
      if (assignment) await updateAssignment(outletId, item.id, body);
      else await assignMenuItem(outletId, { menuItemId: item.id, ...body });
      toast.success(`${item.name} ${assignment ? 'updated' : 'assigned'}`);
      onSaved();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <tr className={item.isActive ? '' : 'dim'}>
      <td>
        {item.name}
        {!item.isActive && <span className="muted small"> (inactive)</span>}
      </td>
      <td className="num">{money(item.basePrice)}</td>
      <td>{assignment ? <Badge tone="green">Assigned</Badge> : <Badge>Not assigned</Badge>}</td>
      <td>
        <input
          className="input-sm" type="number" min="0" step="0.01"
          placeholder="Use base" value={price} onChange={(e) => setPrice(e.target.value)}
        />
      </td>
      <td>
        <label className="switch">
          <input type="checkbox" checked={available} onChange={(e) => setAvailable(e.target.checked)} />
          <span />
        </label>
      </td>
      <td className="row-actions">
        <button className={assignment ? 'btn btn-sm' : 'btn btn-sm btn-primary'} disabled={saving} onClick={save}>
          {saving ? 'Saving…' : assignment ? 'Save' : 'Assign'}
        </button>
      </td>
    </tr>
  );
}
