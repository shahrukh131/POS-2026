import { useState } from 'react';
import { asList, createOutlet, listOutlets, normOutlet } from '../api';
import { DataState, Field, Modal, PageHeader, useAsync, useToast } from '../ui';
import { useRole } from '../role';

export default function Outlets() {
  const q = useAsync(async () => asList(await listOutlets()).map(normOutlet));
  const [open, setOpen] = useState(false);
  const rows = q.data || [];

  return (
    <>
      <PageHeader
        title="Outlets"
        subtitle="All restaurant branches managed by HQ."
        actions={<button className="btn btn-primary" onClick={() => setOpen(true)}>+ Add outlet</button>}
      />
      <div className="card">
        <DataState q={q} isEmpty={!rows.length} empty="No outlets yet. Add your first outlet.">
          <table className="table">
            <thead><tr><th>Code</th><th>Name</th><th>Address</th><th>Created</th></tr></thead>
            <tbody>
              {rows.map((o) => (
                <tr key={o.id}>
                  <td><span className="code">{o.code}</span></td>
                  <td>{o.name}</td>
                  <td className="muted">{o.address || '—'}</td>
                  <td className="muted">{o.createdAt ? new Date(o.createdAt).toLocaleDateString() : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </DataState>
      </div>
      {open && <AddOutlet onClose={() => setOpen(false)} onSaved={q.reload} />}
    </>
  );
}

function AddOutlet({ onClose, onSaved }) {
  const toast = useToast();
  const { refreshOutlets } = useRole();
  const [form, setForm] = useState({ code: '', name: '', address: '' });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await createOutlet({ ...form, code: form.code.trim().toUpperCase() });
      toast.success(`Outlet ${form.name} created`);
      onSaved();
      refreshOutlets();
      onClose();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title="Add outlet" onClose={onClose}>
      <form onSubmit={submit} className="form">
        <Field label="Code" hint="Short unique code used in receipts, e.g. DHA">
          <input value={form.code} onChange={set('code')} required maxLength={10} placeholder="DHA" />
        </Field>
        <Field label="Name">
          <input value={form.name} onChange={set('name')} required placeholder="Dhanmondi" />
        </Field>
        <Field label="Address">
          <input value={form.address} onChange={set('address')} placeholder="Road 27, Dhanmondi" />
        </Field>
        <div className="form-actions">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Create'}</button>
        </div>
      </form>
    </Modal>
  );
}
