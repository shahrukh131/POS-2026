import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { ToastProvider } from './ui';
import { RoleProvider } from './role';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <RoleProvider>
          <App />
        </RoleProvider>
      </ToastProvider>
    </BrowserRouter>
  </React.StrictMode>
);
